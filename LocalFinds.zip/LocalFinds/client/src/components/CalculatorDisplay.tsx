import { cn } from "@/lib/utils";

interface CalculatorDisplayProps {
  expression: string;
  result: string;
  error?: boolean;
  className?: string;
}

export default function CalculatorDisplay({
  expression,
  result,
  error = false,
  className,
}: CalculatorDisplayProps) {
  return (
    <div
      className={cn(
        "bg-card border-b border-card-border p-6 min-h-32 flex flex-col justify-end",
        className
      )}
      data-testid="calculator-display"
    >
      <div className="text-right overflow-x-auto scrollbar-none">
        <div
          className="text-muted-foreground text-xl mb-2 font-mono whitespace-nowrap"
          data-testid="display-expression"
        >
          {expression || "0"}
        </div>
        <div
          className={cn(
            "text-4xl font-bold font-mono whitespace-nowrap",
            error ? "text-destructive" : "text-foreground"
          )}
          data-testid="display-result"
        >
          {result || "0"}
        </div>
      </div>
    </div>
  );
}
