import { useState } from "react";
import { X, ArrowDownUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface UnitConverterProps {
  isOpen: boolean;
  onClose: () => void;
}

const conversions = {
  length: {
    units: ["meters", "kilometers", "feet", "miles", "inches", "centimeters"],
    convert: (value: number, from: string, to: string) => {
      const toMeters: Record<string, number> = {
        meters: 1,
        kilometers: 1000,
        feet: 0.3048,
        miles: 1609.34,
        inches: 0.0254,
        centimeters: 0.01,
      };
      return (value * toMeters[from]) / toMeters[to];
    },
  },
  weight: {
    units: ["kilograms", "grams", "pounds", "ounces", "tons"],
    convert: (value: number, from: string, to: string) => {
      const toKg: Record<string, number> = {
        kilograms: 1,
        grams: 0.001,
        pounds: 0.453592,
        ounces: 0.0283495,
        tons: 1000,
      };
      return (value * toKg[from]) / toKg[to];
    },
  },
  temperature: {
    units: ["celsius", "fahrenheit", "kelvin"],
    convert: (value: number, from: string, to: string) => {
      let celsius = value;
      if (from === "fahrenheit") celsius = (value - 32) * (5 / 9);
      if (from === "kelvin") celsius = value - 273.15;
      
      if (to === "fahrenheit") return celsius * (9 / 5) + 32;
      if (to === "kelvin") return celsius + 273.15;
      return celsius;
    },
  },
  volume: {
    units: ["liters", "milliliters", "gallons", "cups", "fluid ounces"],
    convert: (value: number, from: string, to: string) => {
      const toLiters: Record<string, number> = {
        liters: 1,
        milliliters: 0.001,
        gallons: 3.78541,
        cups: 0.236588,
        "fluid ounces": 0.0295735,
      };
      return (value * toLiters[from]) / toLiters[to];
    },
  },
};

export default function UnitConverter({ isOpen, onClose }: UnitConverterProps) {
  const [category, setCategory] = useState<keyof typeof conversions>("length");
  const [fromValue, setFromValue] = useState("");
  const [fromUnit, setFromUnit] = useState(conversions[category].units[0]);
  const [toUnit, setToUnit] = useState(conversions[category].units[1]);

  if (!isOpen) return null;

  const handleCategoryChange = (newCategory: string) => {
    const cat = newCategory as keyof typeof conversions;
    setCategory(cat);
    setFromUnit(conversions[cat].units[0]);
    setToUnit(conversions[cat].units[1]);
    setFromValue("");
  };

  const handleSwap = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
  };

  const convertedValue = fromValue
    ? conversions[category].convert(
        parseFloat(fromValue) || 0,
        fromUnit,
        toUnit
      ).toFixed(4)
    : "";

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 animate-in slide-in-from-top duration-300">
      <div className="h-full flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-xl font-semibold" data-testid="text-converter-title">Unit Converter</h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            data-testid="button-close-converter"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        <div className="flex-1 overflow-auto p-4">
          <Tabs value={category} onValueChange={handleCategoryChange}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="length" data-testid="tab-length">Length</TabsTrigger>
              <TabsTrigger value="weight" data-testid="tab-weight">Weight</TabsTrigger>
              <TabsTrigger value="temperature" data-testid="tab-temperature">Temp</TabsTrigger>
              <TabsTrigger value="volume" data-testid="tab-volume">Volume</TabsTrigger>
            </TabsList>

            <TabsContent value={category} className="mt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="from-value">From</Label>
                <div className="flex gap-2">
                  <Input
                    id="from-value"
                    type="number"
                    value={fromValue}
                    onChange={(e) => setFromValue(e.target.value)}
                    placeholder="0"
                    className="flex-1"
                    data-testid="input-from-value"
                  />
                  <Select value={fromUnit} onValueChange={setFromUnit}>
                    <SelectTrigger className="w-40" data-testid="select-from-unit">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {conversions[category].units.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-center">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={handleSwap}
                  data-testid="button-swap-units"
                >
                  <ArrowDownUp className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label htmlFor="to-value">To</Label>
                <div className="flex gap-2">
                  <Input
                    id="to-value"
                    type="number"
                    value={convertedValue}
                    readOnly
                    placeholder="0"
                    className="flex-1 bg-muted"
                    data-testid="input-to-value"
                  />
                  <Select value={toUnit} onValueChange={setToUnit}>
                    <SelectTrigger className="w-40" data-testid="select-to-unit">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {conversions[category].units.map((unit) => (
                        <SelectItem key={unit} value={unit}>
                          {unit}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
