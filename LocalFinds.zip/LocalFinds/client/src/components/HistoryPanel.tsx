import { X, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";

export interface HistoryEntry {
  id: string;
  expression: string;
  result: string;
  timestamp: number;
}

interface HistoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  history: HistoryEntry[];
  onSelectEntry: (entry: HistoryEntry) => void;
  onClearHistory: () => void;
}

export default function HistoryPanel({
  isOpen,
  onClose,
  history,
  onSelectEntry,
  onClearHistory,
}: HistoryPanelProps) {
  const { toast } = useToast();

  if (!isOpen) return null;

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        description: "Copied to clipboard",
      });
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 animate-in slide-in-from-top duration-300">
      <div className="h-full flex flex-col">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-xl font-semibold" data-testid="text-history-title">History</h2>
          <div className="flex gap-2">
            {history.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClearHistory}
                data-testid="button-clear-history"
              >
                Clear All
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-history"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="p-4 space-y-2">
            {history.length === 0 ? (
              <div className="text-center text-muted-foreground py-12" data-testid="text-no-history">
                No calculation history
              </div>
            ) : (
              history.map((entry) => (
                <div
                  key={entry.id}
                  className="bg-card border border-card-border rounded-lg p-4 hover-elevate cursor-pointer"
                  onClick={() => {
                    onSelectEntry(entry);
                    onClose();
                  }}
                  data-testid={`history-entry-${entry.id}`}
                >
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm text-muted-foreground mb-1 font-mono">
                        {entry.expression}
                      </div>
                      <div className="text-xl font-bold font-mono">
                        = {entry.result}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="shrink-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCopy(entry.result);
                      }}
                      data-testid={`button-copy-${entry.id}`}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}
