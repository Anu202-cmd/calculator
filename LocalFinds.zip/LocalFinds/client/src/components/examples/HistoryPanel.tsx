import { useState } from "react";
import HistoryPanel, { HistoryEntry } from "../HistoryPanel";
import { Button } from "@/components/ui/button";

export default function HistoryPanelExample() {
  const [isOpen, setIsOpen] = useState(true);
  
  const mockHistory: HistoryEntry[] = [
    { id: "1", expression: "15 + 25", result: "40", timestamp: Date.now() - 1000 },
    { id: "2", expression: "100 - 37", result: "63", timestamp: Date.now() - 2000 },
    { id: "3", expression: "8 × 9", result: "72", timestamp: Date.now() - 3000 },
  ];

  return (
    <div className="h-screen bg-background">
      <Button onClick={() => setIsOpen(true)} data-testid="button-open-history">
        Open History
      </Button>
      <HistoryPanel
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        history={mockHistory}
        onSelectEntry={(entry) => console.log("Selected:", entry)}
        onClearHistory={() => console.log("Clear history")}
      />
    </div>
  );
}
