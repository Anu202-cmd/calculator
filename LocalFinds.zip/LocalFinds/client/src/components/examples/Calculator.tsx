import Calculator from "../../pages/Calculator";

export default function CalculatorExample() {
  return <Calculator />;
}
