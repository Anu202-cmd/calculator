import CalculatorButton from "../CalculatorButton";

export default function CalculatorButtonExample() {
  return (
    <div className="grid grid-cols-4 gap-2 p-4 bg-background">
      <CalculatorButton value="7" onClick={(v) => console.log(v)} />
      <CalculatorButton value="8" onClick={(v) => console.log(v)} />
      <CalculatorButton value="9" onClick={(v) => console.log(v)} />
      <CalculatorButton value="÷" variant="operator" onClick={(v) => console.log(v)} />
      <CalculatorButton value="4" onClick={(v) => console.log(v)} />
      <CalculatorButton value="5" onClick={(v) => console.log(v)} />
      <CalculatorButton value="6" onClick={(v) => console.log(v)} />
      <CalculatorButton value="×" variant="operator" onClick={(v) => console.log(v)} />
      <CalculatorButton value="=" variant="equals" onClick={(v) => console.log(v)} />
    </div>
  );
}
