import CalculatorDisplay from "../CalculatorDisplay";

export default function CalculatorDisplayExample() {
  return (
    <div className="bg-background">
      <CalculatorDisplay
        expression="15 + 25"
        result="40"
      />
      <div className="mt-4">
        <CalculatorDisplay
          expression="10 ÷ 0"
          result="Error"
          error={true}
        />
      </div>
    </div>
  );
}
