import { useState } from "react";
import UnitConverter from "../UnitConverter";
import { Button } from "@/components/ui/button";

export default function UnitConverterExample() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="h-screen bg-background">
      <Button onClick={() => setIsOpen(true)} data-testid="button-open-converter">
        Open Converter
      </Button>
      <UnitConverter isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </div>
  );
}
