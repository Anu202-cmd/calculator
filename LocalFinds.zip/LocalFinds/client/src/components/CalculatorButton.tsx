import { cn } from "@/lib/utils";

interface CalculatorButtonProps {
  value: string;
  display?: string;
  onClick: (value: string) => void;
  variant?: "number" | "operator" | "equals" | "function" | "clear";
  className?: string;
  colspan?: number;
}

export default function CalculatorButton({
  value,
  display,
  onClick,
  variant = "number",
  className,
  colspan = 1,
}: CalculatorButtonProps) {
  const baseClasses = "min-h-16 rounded-lg font-medium text-lg transition-all active-elevate-2 select-none touch-manipulation";
  
  const variantClasses = {
    number: "bg-secondary text-secondary-foreground",
    operator: "bg-primary text-primary-foreground font-semibold",
    equals: "bg-primary text-primary-foreground font-bold text-xl",
    function: "bg-muted text-muted-foreground text-base",
    clear: "bg-destructive/10 text-destructive font-semibold",
  };

  const colspanClasses = {
    1: "",
    2: "col-span-2",
    3: "col-span-3",
    4: "col-span-4",
  };

  return (
    <button
      data-testid={`button-calc-${value.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
      onClick={() => onClick(value)}
      className={cn(
        baseClasses,
        variantClasses[variant],
        colspanClasses[colspan as keyof typeof colspanClasses],
        className
      )}
    >
      {display || value}
    </button>
  );
}
