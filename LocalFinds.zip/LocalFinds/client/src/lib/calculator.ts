export function evaluateExpression(expression: string): string {
  try {
    const sanitized = expression
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/π/g, Math.PI.toString())
      .replace(/e(?![0-9])/g, Math.E.toString());

    const result = Function(`'use strict'; return (${sanitized})`)();
    
    if (!isFinite(result)) {
      return "Error";
    }
    
    const rounded = Number(result.toPrecision(12));
    return rounded.toString();
  } catch (error) {
    return "Error";
  }
}

export function evaluateScientific(expression: string): string {
  try {
    let processed = expression
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/π/g, Math.PI.toString())
      .replace(/e(?![0-9])/g, Math.E.toString())
      .replace(/sin\(/g, "Math.sin(")
      .replace(/cos\(/g, "Math.cos(")
      .replace(/tan\(/g, "Math.tan(")
      .replace(/log\(/g, "Math.log10(")
      .replace(/ln\(/g, "Math.log(")
      .replace(/√\(/g, "Math.sqrt(")
      .replace(/√/g, "Math.sqrt")
      .replace(/(\d+)!/g, (match, num) => factorial(parseInt(num)).toString())
      .replace(/(\d+)\^(\d+)/g, "Math.pow($1,$2)");

    const result = Function(`'use strict'; return (${processed})`)();
    
    if (!isFinite(result)) {
      return "Error";
    }
    
    const rounded = Number(result.toPrecision(12));
    return rounded.toString();
  } catch (error) {
    return "Error";
  }
}

function factorial(n: number): number {
  if (n < 0) return NaN;
  if (n === 0 || n === 1) return 1;
  let result = 1;
  for (let i = 2; i <= n; i++) {
    result *= i;
  }
  return result;
}
