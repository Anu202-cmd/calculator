import { useState, useEffect } from "react";
import { Clock, Ruler, Delete } from "lucide-react";
import { Button } from "@/components/ui/button";
import CalculatorButton from "@/components/CalculatorButton";
import CalculatorDisplay from "@/components/CalculatorDisplay";
import HistoryPanel, { HistoryEntry } from "@/components/HistoryPanel";
import UnitConverter from "@/components/UnitConverter";
import { evaluateExpression, evaluateScientific } from "@/lib/calculator";

export default function Calculator() {
  const [expression, setExpression] = useState("");
  const [result, setResult] = useState("0");
  const [error, setError] = useState(false);
  const [isScientific, setIsScientific] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showConverter, setShowConverter] = useState(false);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  useEffect(() => {
    const savedHistory = localStorage.getItem("calculator-history");
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }

    const handleOrientationChange = () => {
      setIsScientific(window.innerWidth > window.innerHeight);
    };

    handleOrientationChange();
    window.addEventListener("resize", handleOrientationChange);
    return () => window.removeEventListener("resize", handleOrientationChange);
  }, []);

  useEffect(() => {
    localStorage.setItem("calculator-history", JSON.stringify(history));
  }, [history]);

  const handleButtonClick = (value: string) => {
    setError(false);

    if (value === "AC") {
      setExpression("");
      setResult("0");
    } else if (value === "DEL") {
      setExpression((prev) => prev.slice(0, -1));
      if (expression.length <= 1) {
        setResult("0");
      }
    } else if (value === "=") {
      if (!expression) return;
      
      const evalResult = isScientific 
        ? evaluateScientific(expression)
        : evaluateExpression(expression);
      
      if (evalResult === "Error") {
        setError(true);
        setResult("Error");
      } else {
        setResult(evalResult);
        const newEntry: HistoryEntry = {
          id: Date.now().toString(),
          expression,
          result: evalResult,
          timestamp: Date.now(),
        };
        setHistory((prev) => [newEntry, ...prev.slice(0, 99)]);
      }
    } else {
      setExpression((prev) => prev + value);
    }
  };

  const handleHistorySelect = (entry: HistoryEntry) => {
    setExpression(entry.expression);
    setResult(entry.result);
    setError(false);
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.removeItem("calculator-history");
  };

  const basicButtons = [
    { value: "AC", variant: "clear" as const },
    { value: "DEL", variant: "clear" as const, display: "⌫" },
    { value: "%", variant: "function" as const },
    { value: "÷", variant: "operator" as const },
    { value: "7", variant: "number" as const },
    { value: "8", variant: "number" as const },
    { value: "9", variant: "number" as const },
    { value: "×", variant: "operator" as const },
    { value: "4", variant: "number" as const },
    { value: "5", variant: "number" as const },
    { value: "6", variant: "number" as const },
    { value: "-", variant: "operator" as const },
    { value: "1", variant: "number" as const },
    { value: "2", variant: "number" as const },
    { value: "3", variant: "number" as const },
    { value: "+", variant: "operator" as const },
    { value: "0", variant: "number" as const, colspan: 2 },
    { value: ".", variant: "number" as const },
    { value: "=", variant: "equals" as const },
  ];

  const scientificButtons = [
    { value: "sin(", variant: "function" as const, display: "sin" },
    { value: "cos(", variant: "function" as const, display: "cos" },
    { value: "tan(", variant: "function" as const, display: "tan" },
    { value: "log(", variant: "function" as const, display: "log" },
    { value: "ln(", variant: "function" as const, display: "ln" },
    { value: "√(", variant: "function" as const, display: "√" },
    { value: "^", variant: "function" as const, display: "x²" },
    { value: "(", variant: "function" as const },
    { value: ")", variant: "function" as const },
    { value: "π", variant: "function" as const },
    { value: "e", variant: "function" as const },
    { value: "!", variant: "function" as const },
  ];

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <div className="flex items-center justify-between p-2 border-b border-border bg-card">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setShowHistory(true)}
          data-testid="button-open-history"
        >
          <Clock className="h-5 w-5" />
        </Button>
        <h1 className="text-lg font-semibold" data-testid="text-app-title">Calculator</h1>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setShowConverter(true)}
          data-testid="button-open-converter"
        >
          <Ruler className="h-5 w-5" />
        </Button>
      </div>

      <CalculatorDisplay
        expression={expression}
        result={result}
        error={error}
      />

      {isScientific ? (
        <div className="flex-1 p-2 grid grid-cols-7 gap-2 overflow-auto">
          {scientificButtons.map((btn, idx) => (
            <CalculatorButton
              key={idx}
              value={btn.value}
              display={btn.display}
              variant={btn.variant}
              onClick={handleButtonClick}
            />
          ))}
          {basicButtons.map((btn, idx) => (
            <CalculatorButton
              key={idx}
              value={btn.value}
              display={btn.display}
              variant={btn.variant}
              colspan={btn.colspan}
              onClick={handleButtonClick}
            />
          ))}
        </div>
      ) : (
        <div className="flex-1 p-2 grid grid-cols-4 gap-2">
          {basicButtons.map((btn, idx) => (
            <CalculatorButton
              key={idx}
              value={btn.value}
              display={btn.display}
              variant={btn.variant}
              colspan={btn.colspan}
              onClick={handleButtonClick}
            />
          ))}
        </div>
      )}

      <HistoryPanel
        isOpen={showHistory}
        onClose={() => setShowHistory(false)}
        history={history}
        onSelectEntry={handleHistorySelect}
        onClearHistory={handleClearHistory}
      />

      <UnitConverter
        isOpen={showConverter}
        onClose={() => setShowConverter(false)}
      />
    </div>
  );
}
