# Samsung Galaxy Note9 Scientific Calculator - Design Guidelines

## Design Approach

**Reference-Based Design**: Samsung Galaxy Note9 Calculator + One UI Design System

This calculator replicates Samsung's refined calculator interface, known for its clean aesthetic, color-coded operators, and intuitive layout. The design prioritizes thumb-friendly operation, clear visual hierarchy, and seamless mode switching between basic and scientific functions.

**Key Design Principles:**
- Familiar calculator conventions with Samsung polish
- Touch-optimized button sizing and spacing
- Color differentiation for cognitive load reduction
- One-handed portrait operation, two-handed landscape scientific mode
- Minimal chrome, maximum functionality

---

## Typography

**Primary Font**: Roboto or Samsung One UI's Inter equivalent
- **Display Numbers**: 48px, Medium weight (calculation results)
- **Input Equation**: 24px, Regular weight (current input)
- **Button Labels**: 20px, Medium weight (number keys)
- **Function Labels**: 16px, Medium weight (scientific functions)
- **History/Converter Text**: 14px, Regular weight

**Monospaced Display**: Use tabular numbers for result display to prevent layout shift

---

## Layout System

**Spacing Primitives**: Tailwind units of 1, 2, 3, 4, and 6
- Button padding: p-4 to p-6 depending on function type
- Grid gaps: gap-2 (between calculator buttons)
- Display padding: p-6 (top result area)
- Section spacing: space-y-4 (history entries, converter options)

**Portrait Mode Layout**:
- Full-height mobile viewport
- Display area: Top 30% with right-aligned text
- Button grid: Bottom 70% in 4×5 grid (numbers, operators, equals)
- Buttons occupy equal space with minimal gaps

**Landscape Mode Layout**:
- Display area: Left 35% with results
- Button grid: Right 65% expanded to 6×7 grid including scientific functions
- Maintains button size consistency, adds function rows

**Container Strategy**:
- No max-width constraints - calculator fills available width
- Portrait: Single column button grid
- Landscape: Two-section layout (display | expanded grid)

---

## Component Library

### Display Area
- **Background**: Dark surface with subtle depth
- **Input Text**: Right-aligned, scrollable horizontally for long equations
- **Result Text**: Bold, prominent, right-aligned below input
- **Error States**: Red text for "Error" or "Math Error" messages

### Button Grid - Number Keys (0-9)
- **Shape**: Rounded rectangles (rounded-xl or rounded-2xl)
- **Size**: Minimum 64px height for touch targets
- **Hierarchy**: Slightly darker than operators to recede visually

### Button Grid - Basic Operators (+, -, ×, ÷, =)
- **Visual Treatment**: Accent color background (Samsung blue/teal)
- **Size**: Same as number keys, but visually distinct
- **Equals Button**: Full-width or double-width, prominent accent color
- **Position**: Right column in portrait, integrated in landscape grid

### Button Grid - Scientific Functions
- **Functions**: sin, cos, tan, log, ln, √, x², π, e, (, )
- **Layout**: Appear only in landscape mode above number keys
- **Size**: Slightly smaller labels (16px) to fit more functions
- **Organization**: Trigonometric group, logarithmic group, algebraic group

### Clear/Delete Buttons
- **AC (All Clear)**: Full clear, destructive action styling
- **DEL (Delete)**: Backspace functionality, less prominent than AC
- **Position**: Top row adjacent to display

### Mode Toggle Icons
- **History Icon**: Clock symbol, top-left corner
- **Converter Icon**: Ruler symbol, top-right corner
- **Scientific Mode Indicator**: Subtle badge when in landscape

### History Panel (Slide-in from top)
- **Layout**: List of past calculations with timestamp
- **Entry Format**: "Equation = Result" on each line
- **Interaction**: Tap to copy, long-press to delete
- **Max Height**: 60vh with scroll overflow
- **Animation**: Smooth slide-down reveal

### Unit Converter (Slide-in from top)
- **Category Tabs**: Length, Weight, Temperature, Volume, Currency
- **Input Fields**: Two large input boxes with unit dropdowns
- **Swap Button**: Centered between inputs for quick reversal
- **Layout**: Vertical stack with clear labels and spacing

---

## Visual Hierarchy & Color Strategy

**No specific colors specified here** - focus on semantic roles:
- **Display Surface**: Darkest background for contrast
- **Number Keys**: Secondary background, less prominent
- **Operator Keys**: Accent background, eye-catching
- **Equals Button**: Primary action color, strongest emphasis
- **Scientific Functions**: Tertiary background, organized visually
- **Text**: High contrast for readability on all backgrounds

**Visual Weight Distribution**:
1. Equals button (heaviest visual weight)
2. Basic operators (medium-high weight)
3. Display area (medium weight)
4. Number keys (lighter weight)
5. Scientific functions (lightest weight)

---

## Interaction Patterns

### Button Press States
- **Touch Feedback**: Immediate visual response (scale or opacity shift)
- **Active State**: Slight depression effect or background darkening
- **Ripple Effect**: Material-style ripple emanating from touch point
- **No Hover States**: Mobile-first means no desktop hover styling

### Orientation Change Behavior
- **Portrait → Landscape**: Smooth expansion revealing scientific functions
- **State Preservation**: Current calculation remains visible during transition
- **Animation Duration**: 300ms ease-out transition

### History Interaction
- **Gesture**: Swipe down from top or tap history icon
- **Dismissal**: Tap outside panel or swipe up to close
- **Result Reuse**: Tap history entry to populate main display

### Copy/Paste Functionality
- **Long Press Display**: Shows copy option for result
- **Double Tap**: Selects entire equation for copying
- **Paste Target**: Tap display area when clipboard has numbers

---

## Responsive Behavior

**Mobile Portrait (320px - 480px)**:
- Basic calculator mode only
- 4-column button grid
- Full-width buttons with 2px gaps
- Display takes 25-30% of viewport height

**Mobile Landscape (481px - 768px)**:
- Scientific calculator mode activates
- 6-7 column expanded grid
- Display shifts to left sidebar
- Function buttons appear in organized rows

**Tablet/Desktop (769px+)**:
- Calculator maintains mobile dimensions, centers in viewport
- Max-width: 480px for portrait, 800px for landscape
- Does not scale infinitely - preserves calculator form factor

---

## Progressive Web App Elements

### Installation Prompt
- **Timing**: After 2-3 uses or manual trigger via menu
- **Design**: Minimal banner or modal with "Add to Home Screen" instruction
- **Icon**: Matches Samsung calculator aesthetic

### Offline Capability
- **Full Functionality**: All calculations work offline
- **History Persistence**: Local storage saves calculation history
- **Converter Data**: Pre-loaded unit conversion rates

### App Shell
- **No Navigation Bar**: Immersive calculator experience
- **Status Bar**: Matches system theme (light/dark)
- **Splash Screen**: Simple loading state with calculator icon

---

## Accessibility Considerations

- **Font Scaling**: Respects system font size preferences up to 150%
- **Touch Targets**: Minimum 48px × 48px for all interactive elements
- **ARIA Labels**: Screen reader announces button values and results
- **Keyboard Support**: Desktop users can use number pad and operators
- **Focus Indicators**: Visible focus rings for keyboard navigation
- **Error Feedback**: Both visual and announced errors for invalid operations

---

## Images

**No hero images or decorative imagery required.** This is a functional calculator application focused entirely on usability and computational accuracy. The visual design relies on typography, color-coding, and layout rather than imagery.